﻿using System.Collections.Generic;

namespace ContactManager.Models
{
    public interface IContactManagerService
    {
        bool CreateContact(int groupId, Contact contactToCreate);
        bool DeleteContact(Contact contactToDelete);
        bool EditContact(int groupId, Contact contactToEdit);
        Contact GetContact(int id);


        bool CreateGroup(Group groupToCreate);
        IEnumerable<Group> ListGroups();
        Group GetGroup(int? id);
        bool DeleteGroup(Group groupToDelete);
    }
}
