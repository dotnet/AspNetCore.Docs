using System.Web.Mvc;
using System.Linq;
using ContactManager.Models;
using ContactManager.Models.ViewData;
using ContactManager.Models.Validation;

namespace ContactManager.Controllers
{
    public class ContactController : Controller
    {
        private IContactManagerService _service;

        public ContactController()
        {
            _service = new ContactManagerService(new ModelStateWrapper(this.ModelState));
        }

        public ContactController(IContactManagerService service)
        {
            _service = service;
        }
        
        public ActionResult Index(int? id)
        {
            var model = new IndexModel
            {
                Groups = _service.ListGroups(),
                SelectedGroup = _service.GetGroup(id)
            };

            if (model.SelectedGroup == null)
                return RedirectToAction("Index", "Group");

            return View(model);
        }

        public ActionResult Create()
        {
            if (!AddGroupsToViewData(-1))
                return RedirectToAction("Index", "Group");
            return View("Create");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(int groupId, [Bind(Exclude = "Id")] Contact contactToCreate)
        {
            if (_service.CreateContact(groupId, contactToCreate))
                return RedirectToAction("Index", new {id=groupId});
            AddGroupsToViewData(groupId);           
            return View("Create");
        }

        public ActionResult Edit(int id)
        {
            var contactToEdit = _service.GetContact(id);
            AddGroupsToViewData(contactToEdit.Group.Id);
            return View("Edit", contactToEdit);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int groupId, Contact contactToEdit)
        {
            if (_service.EditContact(groupId, contactToEdit))
                return RedirectToAction("Index", new {id=groupId });
            AddGroupsToViewData(groupId);
            return View("Edit");
        }

        public ActionResult Delete(int id)
        {
            return View("Delete", _service.GetContact(id));
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Delete(Contact contactToDelete)
        {
            if (_service.DeleteContact(contactToDelete))
                return RedirectToAction("Index");
            return View("Delete", _service.GetContact(contactToDelete.Id));
        }

        protected bool AddGroupsToViewData(int selectedId)
        {
            var groups = _service.ListGroups();
            ViewData["GroupId"] = new SelectList(groups, "Id", "Name", selectedId);
            return groups.Count() > 0;
        }

    }
}
