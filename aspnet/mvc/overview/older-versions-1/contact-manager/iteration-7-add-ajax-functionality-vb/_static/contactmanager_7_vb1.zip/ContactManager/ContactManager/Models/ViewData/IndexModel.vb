﻿Public Class IndexModel

	Private _selectedGroup As Group
	Private _groups As IEnumerable(Of Group)

	Public Property SelectedGroup() As Group
		Get
			Return _selectedGroup
		End Get
		Set(ByVal value As Group)
			_selectedGroup = value
		End Set
	End Property

	Public Property Groups() As IEnumerable(Of Group)
		Get
			Return _groups
		End Get
		Set(ByVal value As IEnumerable(Of Group))
			_groups = value
		End Set
	End Property
End Class
