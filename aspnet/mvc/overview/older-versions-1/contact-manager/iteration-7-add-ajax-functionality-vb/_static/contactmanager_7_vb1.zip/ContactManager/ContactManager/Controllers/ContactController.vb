Public Class ContactController
	Inherits Controller
	Private _service As IContactManagerService

	Public Sub New()
		_service = New ContactManagerService(New ModelStateWrapper(Me.ModelState))
	End Sub

	Public Sub New(ByVal service As IContactManagerService)
		_service = service
	End Sub

    Public Function Index(ByVal id As Integer?) As ActionResult
        ' Get selected group
        Dim selectedGroup = _service.GetGroup(id)
        if IsNothing(selectedGroup) Then
            Return RedirectToAction("Index", "Group")
        End If

        ' Normal Request
        if Not Request.IsAjaxRequest() Then
            Dim model As new IndexModel With { _
                .Groups = _service.ListGroups(), _
                .SelectedGroup = selectedGroup _
            }
            Return View("Index", model)
        End If

        ' Ajax Request
        return PartialView("ContactList", selectedGroup)
    End Function

	Public Function Create() As ActionResult
		If (Not AddGroupsToViewData(-1)) Then
			Return RedirectToAction("Index", "Group")
		End If
		Return View("Create")
	End Function

	<AcceptVerbs(HttpVerbs.Post)> _
	Public Function Create(ByVal groupId As Integer, <Bind(Exclude := "Id")> ByVal contactToCreate As Contact) As ActionResult
		If _service.CreateContact(groupId, contactToCreate) Then
			Return RedirectToAction("Index", New With {Key .id=groupId})
		End If
		AddGroupsToViewData(groupId)
		Return View("Create")
	End Function

	Public Function Edit(ByVal id As Integer) As ActionResult
		Dim contactToEdit = _service.GetContact(id)
		AddGroupsToViewData(contactToEdit.Group.Id)
		Return View("Edit", contactToEdit)
	End Function

	<AcceptVerbs(HttpVerbs.Post)> _
	Public Function Edit(ByVal groupId As Integer, ByVal contactToEdit As Contact) As ActionResult
		If _service.EditContact(groupId, contactToEdit) Then
			Return RedirectToAction("Index", New With {Key .id=groupId})
		End If
		AddGroupsToViewData(groupId)
		Return View("Edit")
	End Function

	Public Function Delete(ByVal id As Integer) As ActionResult
		Return View("Delete", _service.GetContact(id))
	End Function

    <AcceptVerbs(HttpVerbs.Delete), ActionName("Delete")> _
    Public Function AjaxDelete(ByVal id As Integer) As ActionResult
        ' Get contact and group
        Dim contactToDelete = _service.GetContact(id)
        Dim selectedGroup = _service.GetGroup(contactToDelete.Group.Id)

        ' Delete from database
        _service.DeleteContact(contactToDelete)

        ' Return Contact List
        Return PartialView("ContactList", selectedGroup)
    End Function

	<AcceptVerbs(HttpVerbs.Post)> _
	Public Function Delete(ByVal contactToDelete As Contact) As ActionResult
		If _service.DeleteContact(contactToDelete) Then
			Return RedirectToAction("Index")
		End If
		Return View("Delete", _service.GetContact(contactToDelete.Id))
	End Function

	Protected Function AddGroupsToViewData(ByVal selectedId As Integer) As Boolean
		Dim groups = _service.ListGroups()
		ViewData("GroupId") = New SelectList(groups, "Id", "Name", selectedId)
		Return groups.Count() > 0
	End Function

End Class
