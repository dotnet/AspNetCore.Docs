﻿Public Module ImageActionLinkHelper

	<System.Runtime.CompilerServices.Extension> _
	Function ImageActionLink(ByVal helper As AjaxHelper, ByVal imageUrl As String, ByVal altText As String, ByVal actionName As String, ByVal routeValues As Object, ByVal ajaxOptions As AjaxOptions) As String
		Dim builder = New TagBuilder("img")
		builder.MergeAttribute("src", imageUrl)
		builder.MergeAttribute("alt", altText)
		Dim link = helper.ActionLink("[replaceme]", actionName, routeValues, ajaxOptions)
		Return link.Replace("[replaceme]", builder.ToString(TagRenderMode.SelfClosing))
	End Function

End Module
