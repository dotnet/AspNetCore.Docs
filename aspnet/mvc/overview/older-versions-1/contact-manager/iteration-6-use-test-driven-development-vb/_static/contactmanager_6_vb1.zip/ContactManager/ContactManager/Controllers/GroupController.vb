Public Class GroupController
	Inherits Controller

	Private _service As IContactManagerService

	Public Sub New()
		_service = New ContactManagerService(New ModelStateWrapper(Me.ModelState))
	End Sub

	Public Sub New(ByVal service As IContactManagerService)
		_service = service
	End Sub

	Public Function Index() As ActionResult
		Return View(_service.ListGroups())
	End Function

	<AcceptVerbs(HttpVerbs.Post)> _
	Public Function Create(<Bind(Exclude:="Id")> ByVal groupToCreate As Group) As ActionResult
		If _service.CreateGroup(groupToCreate) Then
			Return RedirectToAction("Index")
		End If
		Return View("Index", _service.ListGroups())
	End Function

	Public Function Delete(ByVal id As Integer) As ActionResult
		Return View("Delete", _service.GetGroup(id))
	End Function


	<AcceptVerbs(HttpVerbs.Post)> _
	Public Function Delete(ByVal groupToDelete As Group) As ActionResult
		If _service.DeleteGroup(groupToDelete) Then
			Return RedirectToAction("Index")
		End If
		Return View("Delete", _service.GetGroup(groupToDelete.Id))
	End Function



End Class