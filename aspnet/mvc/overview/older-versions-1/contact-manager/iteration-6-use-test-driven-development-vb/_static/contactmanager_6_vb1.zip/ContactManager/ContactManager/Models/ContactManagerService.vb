﻿Public Class ContactManagerService
	Implements IContactManagerService

	Private _validationDictionary As IValidationDictionary
	Private _repository As IContactManagerRepository


	Public Sub New(ByVal validationDictionary As IValidationDictionary)
		Me.New(validationDictionary, New EntityContactManagerRepository())
	End Sub


	Public Sub New(ByVal validationDictionary As IValidationDictionary, ByVal repository As IContactManagerRepository)
		_validationDictionary = validationDictionary
		_repository = repository
	End Sub

	' Contact methods

	Public Function ValidateContact(ByVal contactToValidate As Contact) As Boolean
		If contactToValidate.FirstName.Trim().Length = 0 Then
			_validationDictionary.AddError("FirstName", "First name is required.")
		End If
		If contactToValidate.LastName.Trim().Length = 0 Then
			_validationDictionary.AddError("LastName", "Last name is required.")
		End If
		If contactToValidate.Phone.Length > 0 AndAlso (Not Regex.IsMatch(contactToValidate.Phone, "((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}")) Then
			_validationDictionary.AddError("Phone", "Invalid phone number.")
		End If
		If contactToValidate.Email.Length > 0 AndAlso (Not Regex.IsMatch(contactToValidate.Email, "^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$")) Then
			_validationDictionary.AddError("Email", "Invalid email address.")
		End If
		Return _validationDictionary.IsValid
	End Function


	Public Function CreateContact(ByVal groupId As Integer, ByVal contactToCreate As Contact) As Boolean Implements IContactManagerService.CreateContact
		' Validation logic
		If (Not ValidateContact(contactToCreate)) Then
			Return False
		End If

		' Database logic
		Try
			_repository.CreateContact(groupId, contactToCreate)
		Catch
			Return False
		End Try
		Return True
	End Function

	Public Function EditContact(ByVal groupId As Integer, ByVal contactToEdit As Contact) As Boolean Implements IContactManagerService.EditContact
		' Validation logic
		If (Not ValidateContact(contactToEdit)) Then
			Return False
		End If

		' Database logic
		Try
			_repository.EditContact(groupId, contactToEdit)
		Catch
			Return False
		End Try
		Return True
	End Function

	Public Function DeleteContact(ByVal contactToDelete As Contact) As Boolean Implements IContactManagerService.DeleteContact
		Try
			_repository.DeleteContact(contactToDelete)
		Catch
			Return False
		End Try
		Return True
	End Function

	Public Function GetContact(ByVal id As Integer) As Contact Implements IContactManagerService.GetContact
		Return _repository.GetContact(id)
	End Function


	' Group methods

	Public Function GetGroup(ByVal id As Integer?) As Group Implements IContactManagerService.GetGroup
		If id.HasValue Then
			Return _repository.GetGroup(id.Value)
		End If
		Return _repository.GetFirstGroup()
	End Function


    Public Function ValidateGroup(ByVal groupToValidate As Group) As Boolean
	    If groupToValidate.Name.Trim().Length = 0 Then
		    _validationDictionary.AddError("Name", "Name is required.")
	    End If
	    Return _validationDictionary.IsValid
    End Function


	Public Function CreateGroup(ByVal groupToCreate As Group) As Boolean Implements IContactManagerService.CreateGroup
		' Validation logic
		If (Not ValidateGroup(groupToCreate)) Then
			Return False
		End If

		' Database logic
		Try
			_repository.CreateGroup(groupToCreate)
		Catch
			Return False
		End Try
		Return True
	End Function

	Public Function ListGroups() As IEnumerable(Of Group) Implements IContactManagerService.ListGroups
		Return _repository.ListGroups()
	End Function

	Public Function DeleteGroup(ByVal groupToDelete As Group) As Boolean Implements IContactManagerService.DeleteGroup
		Try
			_repository.DeleteGroup(groupToDelete)
		Catch
			Return False
		End Try
		Return True
	End Function


End Class
