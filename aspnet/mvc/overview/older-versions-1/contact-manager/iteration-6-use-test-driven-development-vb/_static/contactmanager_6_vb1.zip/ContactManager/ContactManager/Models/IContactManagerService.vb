﻿Public Interface IContactManagerService

    ' Contact methods
	Function CreateContact(ByVal groupId As Integer, ByVal contactToCreate As Contact) As Boolean
	Function DeleteContact(ByVal contactToDelete As Contact) As Boolean
	Function EditContact(ByVal groupId As Integer, ByVal contactToEdit As Contact) As Boolean
	Function GetContact(ByVal id As Integer) As Contact

    ' Group methods
	Function CreateGroup(ByVal groupToCreate As Group) As Boolean
	Function ListGroups() As IEnumerable(Of Group)
	Function GetGroup(ByVal id As Integer?) As Group
	Function DeleteGroup(ByVal groupToDelete As Group) As Boolean

End Interface
