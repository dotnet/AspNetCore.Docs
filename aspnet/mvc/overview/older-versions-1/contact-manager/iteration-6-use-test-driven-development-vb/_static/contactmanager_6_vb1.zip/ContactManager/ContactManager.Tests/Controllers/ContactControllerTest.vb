﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Moq
Imports System.Web.Mvc

<TestClass()> _
Public Class ContactControllerTest
    Private _service As Mock(Of IContactManagerService)


    <TestInitialize()> _
    Public Sub Initialize()
        _service = New Mock(Of IContactManagerService)()
    End Sub

    <TestMethod()> _
    Public Sub CreateValidContact()
        ' Arrange
        Dim contact = New Contact()
        _service.Expect(Function(s) s.CreateContact(1, contact)).Returns(True)
        Dim controller = New ContactController(_service.Object)

        ' Act
        Dim result = CType(controller.Create(1, contact), RedirectToRouteResult)

        ' Assert
        Assert.AreEqual("Index", result.RouteValues("action"))
    End Sub


    <TestMethod()> _
    Public Sub CreateInvalidContact()
        ' Arrange
        Dim contact = New Contact()
        contact.Group = New Group()
        _service.Expect(Function(s) s.CreateContact(1, contact)).Returns(False)
        Dim controller = New ContactController(_service.Object)

        ' Act
        Dim result = CType(controller.Create(1, contact), ViewResult)

        ' Assert
        Assert.AreEqual("Create", result.ViewName)
    End Sub


End Class
