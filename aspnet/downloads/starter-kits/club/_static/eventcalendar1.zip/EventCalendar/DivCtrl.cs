﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Simple web control that exposes itself as a div
/// </summary>
public class DivCtrl : WebControl 
{
    private string m_innerText;
    public DivCtrl(string innerText) : base(HtmlTextWriterTag.Div)
	{
		//
		// TODO: Add constructor logic here
		//
        m_innerText = innerText;
	}

    public DivCtrl() : base(HtmlTextWriterTag.Div)
    {
        //
        // TODO: Add constructor logic here
        //
        m_innerText = null;
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
       if (m_innerText != null) writer.WriteEncodedText(m_innerText);
        base.RenderContents(writer);
    }
}
